const path=require('path')
const mysql=require('mysql')
const express= require('express')

const app=express()
const puerto= process.env.PORT || 3000;
/* para que la info llegue en formato json y sea facil de manipular */
app.use(express.json())
app.use(express.urlencoded({extended:true}))

app.use('/', express.static(path.join(__dirname,'../PUBLIC')))
/* iniciar el servidor */
app.listen(puerto,()=>{
  console.log('SERVIDOR INICIADO en http://localhost:${puerto}')  
})
/*  config con bbdd */
const bd=mysql.createPool({
    host:'localhost',
    user:'root',
    database: 'BBDDRESTAURANTE'
})
    app.post('/insertar', (req, res) => {
        const { tipo_cliente, mesa, tipo_producto1, categoria_producto1, nombre_producto1, cantidad1, Id_mesero } = req.body;
        console.log(req.body);
        const sql = `INSERT INTO Pedidos (tipo_cliente, mesa, tipo_producto, categoria_producto, nombre_producto, cantidad, id_mesero)
                     VALUES (?, ?, ?, ?, ?, ?, ?)`;
    
        bd.query(sql, [tipo_cliente, mesa, tipo_producto1, categoria_producto1, nombre_producto1, cantidad1, Id_mesero], (err, result) => {
            if (err) {
                console.error('Error al insertar en la base de datos:', err);
                res.status(500).send('Error al procesar la solicitud');
            } else {
                console.log('Datos insertados:', result);
            res.send('Orden generada correctamente');
            }
        });
    });
    