const express = require('express')
const bodyParser = require('body-parser')
const mysql2 = require('mysql2/promise')
const path = require('path');

const app = express()

app.use(bodyParser.urlencoded({ extended: true })) //leer url
app.use(bodyParser.json()) //converit los datos en json

app.use(express.static(path.join(__dirname, 'PUBLIC')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'PUBLIC/index.html'));
});

const db = mysql2.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'BBDD_RESTAURANTE'
})

app.post('/insertar', async (req, res) => {

    const {Id_orden, Mesa_orden, Ord_Fecha, Propina_orden, Id_mesero, Id_tipclient} = req.body

    try 
    {
        const [ORDENRows] = await db.query('INSERT INTO orden(Id_orden, Mesa_orden, Ord_Fecha, Propina_orden, Id_mesero, Id_tipclient) VALUES (?,?,?,?,?,?)', [Id_orden, Mesa_orden, Ord_Fecha, Propina_orden, Id_mesero, Id_tipclient])

        const ordenID = ORDENRows.insertId;
        //Enviar el Id de la nueva ORDEN


        console.log(ORDENRows)
        res.redirect('/index.html');
        }

    catch (error) {
        console.error('El error empieza aqui', error)

    }
})


app.listen(3000, () => {
    console.log('servidor activo')
})